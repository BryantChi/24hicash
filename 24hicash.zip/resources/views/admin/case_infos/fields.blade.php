<!-- Name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('name', '名稱:') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>

<!-- Case Title Field -->
<div class="form-group col-sm-6">
    {!! Form::label('case_title', '標題:') !!}
    {!! Form::text('case_title', null, ['class' => 'form-control']) !!}
</div>

<!-- Case Content Field -->
<div class="form-group col-sm-12 col-lg-12">
    {!! Form::label('case_content', '內容:') !!}
    {!! Form::textarea('case_content', null, ['class' => 'form-control', 'id' => 'contents']) !!}
</div>

@push('third_party_scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.26.1/axios.min.js"
        integrity="sha512-bPh3uwgU5qEMipS/VOmRqynnMXGGSRv+72H/N260MQeXZIK4PG48401Bsby9Nq5P5fz7hy5UGNmC/W1Z51h2GQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    {{-- <script src="https://cdn.tiny.cloud/1/1ugon3r0i7rnpx6jhdz4moygn9knxfai212wbqlixzr9hpi8/tinymce/6/tinymce.min.js"
        referrerpolicy="origin"></script> --}}
    <script src="{!! asset('vendor/tinymce/js/tinymce/tinymce.js') !!}"></script>
@endpush
@push('page_scripts')
<script src="{{ asset('assets/admin/js/cases.js') }}" referrerpolicy="no-referrer"></script>
@endpush

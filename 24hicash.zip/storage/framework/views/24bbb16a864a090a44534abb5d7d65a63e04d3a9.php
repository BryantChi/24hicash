<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/24hicash/resources/views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>
<div class="table-responsive">
    <table class="table" id="aboutUsers-table">
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $adminUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Str::lower($adminUser->name) == 'bryant'): ?>
                <?php continue; ?>
            <?php endif; ?>
            <tr>
                <td><?php echo e($adminUser->name); ?></td>
                <td style="min-width: 300px;"><?php echo e($adminUser->email); ?></td>
                <td width="120">

                    <?php echo Form::open(['route' => ['admin.adminUsers.destroy', $adminUser->id], 'method' => 'delete']); ?>


                    <div class='btn-group <?php echo e($adminUser->id == 1 && Auth::user()->id != 1 ? 'd-none' : ''); ?>'>
                        
                        <?php if(Auth::user()->id <= 2 || Auth::user()->id == $adminUser->id): ?>
                        <a href="<?php echo e(route('admin.adminUsers.edit', [$adminUser->id])); ?>"
                           class='btn btn-default btn-sm'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php endif; ?>
                        <?php if((Auth::user()->id <= 2 && $adminUser->id != 1) || Auth::user()->id == $adminUser->id): ?>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'button', 'class' => 'btn btn-danger btn-sm', 'onclick' => "return check(this)"]); ?>

                        <?php endif; ?>
                    </div>

                    <?php echo Form::close(); ?>


                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/fmd/resources/views/admin/admin_users/table.blade.php ENDPATH**/ ?>
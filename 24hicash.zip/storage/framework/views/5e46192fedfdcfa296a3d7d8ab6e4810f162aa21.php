<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', '名稱:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Case Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('case_title', '標題:'); ?>

    <?php echo Form::text('case_title', null, ['class' => 'form-control']); ?>

</div>

<!-- Case Content Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('case_content', '內容:'); ?>

    <?php echo Form::textarea('case_content', null, ['class' => 'form-control', 'id' => 'contents']); ?>

</div>

<?php $__env->startPush('third_party_scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.26.1/axios.min.js"
        integrity="sha512-bPh3uwgU5qEMipS/VOmRqynnMXGGSRv+72H/N260MQeXZIK4PG48401Bsby9Nq5P5fz7hy5UGNmC/W1Z51h2GQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    <script src="<?php echo asset('vendor/tinymce/js/tinymce/tinymce.js'); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_scripts'); ?>
<script src="<?php echo e(asset('assets/admin/js/cases.js')); ?>" referrerpolicy="no-referrer"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/24hicash/resources/views/admin/case_infos/fields.blade.php ENDPATH**/ ?>
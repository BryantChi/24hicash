<li class="nav-item mb-4">
    <a href="<?php echo e(route('index')); ?>" target="_blank" class="nav-link">
        <span class="h5 mr-2 brand-image"><i class="fas fa-external-link-alt"></i></span>
        <p class="h5"> 瀏覽網站</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('admin.adminUsers.index')); ?>"
        class="nav-link <?php echo e(Request::is('admin/adminUsers*') ? 'active' : ''); ?>">
        <span class="mr-2 brand-image"><i class="fas fa-users-cog"></i></span>
        <p> 管理員</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('admin.seoSettings.index')); ?>"
       class="nav-link <?php echo e(Request::is('admin/seoSettings*') ? 'active' : ''); ?>">
       <span class="mr-2 brand-image"><i class="fas fa-search"></i></span>
        <p>Seo設定</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('admin.caseInfos.index')); ?>"
       class="nav-link <?php echo e(Request::is('admin/caseInfos*') ? 'active' : ''); ?>">
       <span class="mr-2 brand-image"><i class="fas fa-info-circle"></i></span>
        <p>成交案例</p>
    </a>
</li>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/24hicash/resources/views/layouts/menu.blade.php ENDPATH**/ ?>
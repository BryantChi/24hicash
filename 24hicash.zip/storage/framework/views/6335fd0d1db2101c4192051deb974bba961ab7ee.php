<div class="table-responsive">
    <table class="table" id="seoSettings-table">
        <thead>
            <tr>
                <th>Url</th>
                <th>Title</th>
                <th>Description</th>
                <th>Keywords</th>
                <th>Og:title</th>
                <th>Og:description</th>
                <th>Og:site Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $seoSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seoSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($seoSetting->url); ?></td>
                    <td style="min-width: 300px;"><?php echo e($seoSetting->title); ?></td>
                    <td style="min-width: 300px;"><?php echo e($seoSetting->description); ?></td>
                    <td style="min-width: 300px;"><?php echo e($seoSetting->keywords); ?></td>
                    <td style="min-width: 300px;"><?php echo e($seoSetting->og_title); ?></td>
                    <td style="min-width: 300px;"><?php echo e($seoSetting->og_description); ?></td>
                    <td style="min-width: 300px;"><?php echo e($seoSetting->og_site_name); ?></td>
                    <td width="120">
                        <?php echo Form::open(['route' => ['admin.seoSettings.destroy', $seoSetting->id], 'method' => 'delete']); ?>

                        <div class='btn-group'>
                            
                            <a href="<?php echo e(route('admin.seoSettings.edit', [$seoSetting->id])); ?>"
                                class='btn btn-default btn-sm'>
                                <i class="far fa-edit"></i>
                            </a>
                            <?php echo Form::button('<i class="far fa-trash-alt"></i>', [
                                'type' => 'button',
                                'class' => 'btn btn-danger btn-sm',
                                'onclick' => 'return check(this)',
                            ]); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/fmd/resources/views/admin/seo_settings/table.blade.php ENDPATH**/ ?>
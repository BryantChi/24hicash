<div class="table-responsive p-3">
    <table class="table" id="caseInfos-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>職業</th>
                <th>名稱</th>
                <th>案例標題</th>
                <th>案例內容</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $caseInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caseInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($caseInfo->id); ?></td>
                    <td width="120"><?php echo e($caseInfo->occupation); ?></td>
                    <td width="120"><?php echo e($caseInfo->name); ?></td>
                    <td style="min-width: 300px;"><?php echo e($caseInfo->case_title); ?></td>
                    <td style="min-width: 300px;"><?php echo e($caseInfo->case_content); ?></td>
                    <td width="120">
                        <?php echo Form::open(['route' => ['admin.caseInfos.destroy', $caseInfo->id], 'method' => 'delete']); ?>

                        <div class='btn-group'>
                            
                            <a href="<?php echo e(route('admin.caseInfos.edit', [$caseInfo->id])); ?>"
                                class='btn btn-default btn-sm'>
                                <i class="far fa-edit"></i>
                            </a>
                            <?php echo Form::button('<i class="far fa-trash-alt"></i>', [
                                'type' => 'submit',
                                'class' => 'btn btn-danger btn-sm',
                                'onclick' => "return confirm('Are you sure?')",
                            ]); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/fmd/resources/views/admin/case_infos/table.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row h-100 justify-content-center align-items-end">
        <div class="col-12 text-center mb-2">
            <img src="<?php echo e(asset('assets/img/ci.png')); ?>" class="img-fluid mb-3" style="width: 70px;" alt="">
            <p>誠翊資訊網路應用事業</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<style>
    .content-wrapper {
        height: calc(100vh - 60px) !important;
        background-image: url(../assets/img/chenibg01.jpg);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
</style>
<?php $__env->startPush('page_css'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bryantchi/Documents/MWStudio Code/24hicash/resources/views/home.blade.php ENDPATH**/ ?>
<!-- Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('url', 'Url:'); ?>

    <?php echo Form::text('url', null, ['class' => 'form-control', 'placeholder' => 'Url']); ?>

</div>

<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'Title', 'rows' => '5']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Description', 'rows' => '5']); ?>

</div>

<!-- Keywords Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('keywords', 'Keywords:'); ?>

    <?php echo Form::textarea('keywords', null, ['class' => 'form-control', 'placeholder' => 'Keywords', 'rows' => '5']); ?>

</div>

<!-- Og:title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('og:title', 'Og:title:'); ?>

    <?php echo Form::text('og_title', null, ['class' => 'form-control', 'placeholder' => 'Og:title', 'rows' => '5']); ?>

</div>

<!-- Og:site Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('og:site_name', 'Og:site Name:'); ?>

    <?php echo Form::text('og_site_name', null, ['class' => 'form-control', 'placeholder' => 'Og:site Name', 'rows' => '5']); ?>

</div>

<!-- Og:description Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('og:description', 'Og:description:'); ?>

    <?php echo Form::textarea('og_description', null, ['class' => 'form-control', 'placeholder' => 'Og:description', 'rows' => '5']); ?>

</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/24hicash/resources/views/admin/seo_settings/fields.blade.php ENDPATH**/ ?>
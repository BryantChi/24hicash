

<li class="nav-item">
    <a href="<?php echo e(route('admin.adminUsers.index')); ?>"
        class="nav-link <?php echo e(Request::is('admin/adminUsers*') ? 'active' : ''); ?>">
        <span class="mr-2 brand-image"><i class="fas fa-users-cog"></i></span>
        <p> 管理員</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('admin.seoSettings.index')); ?>"
       class="nav-link <?php echo e(Request::is('admin/seoSettings*') ? 'active' : ''); ?>">
       <span class="mr-2 brand-image"><i class="fas fa-search"></i></span>
        <p>Seo設定</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('admin.caseInfos.index')); ?>"
       class="nav-link <?php echo e(Request::is('admin/caseInfos*') ? 'active' : ''); ?>">
       <span class="mr-2 brand-image"><i class="fas fa-info-circle"></i></span>
        <p>實績案例</p>
    </a>
</li>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/fmd/resources/views/layouts/menu.blade.php ENDPATH**/ ?>
<!-- Carousel Start -->
<div class="site-blocks-cover overlay" data-aos="fade" data-stellar-background-ratio="0.5">
    <div id="hero" class="site-blocks-cover2 overlay2">
        <div class="swiper heroSwiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide item1">
                </div>
                <div class="swiper-slide item2">
                </div>
                <div class="swiper-slide item3">
                </div>
            </div>
            <!-- <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div> -->
        </div>
    </div>
</div>
<!-- Carousel End -->
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/24hicash/resources/views/layouts_main/hero.blade.php ENDPATH**/ ?>